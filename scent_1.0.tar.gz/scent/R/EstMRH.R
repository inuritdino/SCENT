EstMRH <-
function(scSR.v,bulkSR){

      avSC <- mean(scSR.v);
      sdSC <- sd(scSR.v);
      z <- (bulkSR-avSC)/sdSC;
      pv <- pnorm(z,0,1,lower.tail=FALSE);

      ### logit basis
      avSC <- mean(log2(scSR.v/(1-scSR.v)));
      sdSC <- sd(log2(scSR.v/(1-scSR.v)));
      zL <- (bulkSR-avSC)/sdSC;        
      pvL <- pnorm(zL,0,1,lower.tail=FALSE);

      ### wilcox-test
      pvWT <- wilcox.test(scSR.v,bulkSR,alt="less")$p.value;

      return(list(rhm=z,pv=pv,rhmL=zL,pvL=pvL,wt=pvWT));
}
